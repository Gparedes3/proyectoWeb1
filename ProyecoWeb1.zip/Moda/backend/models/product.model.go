package models

import "gorm.io/gorm"

type Product struct {
	gorm.Model
	Name        string   `gorm:"type:varchar(100);not null" json:"name"`
	Description string   `gorm:"type:text" json:"description"`
	Price       float64  `gorm:"not null" json:"price"`
	ImageURL    string   `gorm:"type:varchar(255)" json:"image_url"`
	CategoryID  uint     `json:"category_id"`
	Category    Category `gorm:"foreignKey:CategoryID" json:"-"`
}
