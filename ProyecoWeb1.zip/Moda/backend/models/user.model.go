package models

import "gorm.io/gorm"

type User struct {
	gorm.Model
	Name         string  `gorm:"type:varchar(100);not null" json:"name"`
	Email        string  `gorm:"type:varchar(191);uniqueIndex;not null" json:"email"`
	Password     string  `gorm:"type:varchar(255);not null" json:"-"`
	PhoneNumber  string  `gorm:"type:varchar(50)" json:"phoneNumber"`
	AddressLine1 string  `gorm:"type:varchar(255)" json:"addressLine1"`
	City         string  `gorm:"type:varchar(100)" json:"city"`
	PostalCode   string  `gorm:"type:varchar(50)" json:"postalCode"`
	Country      string  `gorm:"type:varchar(100)" json:"country"`
	Orders       []Order `json:"orders,omitempty"`
}
