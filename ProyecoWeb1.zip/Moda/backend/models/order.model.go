package models

import "gorm.io/gorm"

type Order struct {
	gorm.Model
	UserID      uint        `json:"user_id"`
	User        User        `gorm:"foreignKey:UserID" json:"-"`
	TotalAmount float64     `gorm:"not null" json:"total_amount"`
	Status      string      `gorm:"type:varchar(50);default:'completed'" json:"status"`
	Items       []OrderItem `gorm:"foreignKey:OrderID" json:"items"`
}

type OrderItem struct {
	gorm.Model
	OrderID   uint    `json:"-"`
	ProductID uint    `json:"product_id"`
	Product   Product `gorm:"foreignKey:ProductID" json:"product"`
	Quantity  int     `gorm:"not null" json:"quantity"`
	Price     float64 `gorm:"not null" json:"price"`
}
