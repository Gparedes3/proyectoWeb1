import { isLoggedIn, getUsername, clearAuthData } from './auth.js';

function setupNavbar() {
    const authLinksDesktop = document.getElementById('auth-links-desktop');
    const authLinksMobile = document.getElementById('auth-links-mobile');
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    const closeBtn = document.getElementById('close-btn');
    const navbar = document.querySelector('.navbar');

    window.addEventListener('scroll', () => {
        if (!navbar) return;
        navbar.classList.toggle('scrolled', window.scrollY > 20);
    });

    // --- HTML PARA ESCRITORIO (CON DROPDOWN) ---
    const loggedInDesktopHTML = `
        <div class="user-dropdown">
            <a href="#" class="nav-link">${getUsername()} ▼</a>
            <div class="dropdown-content">
                <a href="/public/orders.html" class="dropdown-link">Mis Pedidos</a>
                <a href="#" class="dropdown-link logout-btn">Cerrar Sesión</a>
            </div>
        </div>`;
    
    // --- NUEVO HTML PARA MÓVIL (SIN DROPDOWN, MÁS ELEGANTE) ---
    const loggedInMobileHTML = `
        <div class="mobile-user-section">
            <span class="mobile-user-greeting">Hola, ${getUsername()}</span>
            <a href="/public/orders.html" class="mobile-auth-link">Mis Pedidos</a>
            <a href="#" class="mobile-auth-link logout-btn">Cerrar Sesión</a>
        </div>
    `;

    const loggedOutDesktopHTML = `<a href="/public/login.html" class="btn btn-secondary">Iniciar Sesión</a>`;
    const loggedOutMobileHTML = `<a href="/public/login.html" class="btn btn-primary">Iniciar Sesión</a>`;

    if (isLoggedIn()) {
        if(authLinksDesktop) authLinksDesktop.innerHTML = loggedInDesktopHTML;
        if(authLinksMobile) authLinksMobile.innerHTML = loggedInMobileHTML;
    } else {
        if(authLinksDesktop) authLinksDesktop.innerHTML = loggedOutDesktopHTML;
        if(authLinksMobile) authLinksMobile.innerHTML = loggedOutMobileHTML;
    }

    document.querySelectorAll('.logout-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            clearAuthData();
            window.location.reload();
        });
    });

    const dropdown = document.querySelector('.user-dropdown');
    if (dropdown) {
        dropdown.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.toggle('is-open');
        });
    }

    const toggleMenu = () => {
        mobileMenu.classList.toggle('is-active');
    };
    
    if (hamburgerBtn && mobileMenu && closeBtn) {
        hamburgerBtn.addEventListener('click', toggleMenu);
        closeBtn.addEventListener('click', toggleMenu);
    }

    updateCartCount();
}

export function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCountEl = document.getElementById('cart-count');
    if (cartCountEl) {
        cartCountEl.textContent = count;
        cartCountEl.style.display = count > 0 ? 'inline-flex' : 'none';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const navbarPlaceholder = document.getElementById('navbar-container');
    if (navbarPlaceholder) {
        fetch('/public/components/navbar.html')
            .then(res => res.text())
            .then(html => {
                navbarPlaceholder.innerHTML = html;
                setupNavbar();
            });
    }
});