import { updateCartCount } from '../main.js';

function getCart() {
    return JSON.parse(localStorage.getItem('cart')) || [];
}

function saveCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    renderCartPage(); // Volver a renderizar la página del carrito
}

function renderCartPage() {
    const cart = getCart();
    const wrapper = document.getElementById('cart-wrapper');

    if (cart.length === 0) {
        wrapper.innerHTML = `
            <div class="cart-empty">
                <p>Tu carrito está vacío.</p>
                <a href="/public/shop.html" class="btn btn-primary">Ir a la Tienda</a>
            </div>
        `;
        return;
    }

    let itemsHtml = '';
    let subtotal = 0;

    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        itemsHtml += `
            <div class="cart-item">
                <img src="${item.image_url}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p>$${item.price.toFixed(2)}</p>
                </div>
                <div class="cart-item-quantity">
                    <button class="quantity-btn" data-id="${item.ID}" data-change="-1">-</button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn" data-id="${item.ID}" data-change="1">+</button>
                </div>
                <div class="cart-item-total">$${itemTotal.toFixed(2)}</div>
                <button class="remove-btn" data-id="${item.ID}">&times;</button>
            </div>
        `;
    });

    wrapper.innerHTML = `
        <div class="cart-items-list">
            ${itemsHtml}
        </div>
        <div class="cart-summary">
            <h2>Resumen</h2>
            <div class="summary-row">
                <span>Subtotal</span>
                <span>$${subtotal.toFixed(2)}</span>
            </div>
            <a href="/public/checkout.html" class="btn btn-primary btn-block">Proceder al Pago</a>
        </div>
    `;

    // Añadir event listeners a los nuevos botones
    document.querySelectorAll('.quantity-btn').forEach(button => {
        button.addEventListener('click', handleQuantityChange);
    });
    document.querySelectorAll('.remove-btn').forEach(button => {
        button.addEventListener('click', handleRemoveItem);
    });
}

function handleQuantityChange(e) {
    const productId = parseInt(e.target.dataset.id);
    const change = parseInt(e.target.dataset.change);
    const cart = getCart();
    const item = cart.find(p => p.ID === productId);

    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            // Eliminar si la cantidad llega a 0
            const itemIndex = cart.findIndex(p => p.ID === productId);
            cart.splice(itemIndex, 1);
        }
    }
    saveCart(cart);
}

function handleRemoveItem(e) {
    const productId = parseInt(e.target.dataset.id);
    let cart = getCart();
    cart = cart.filter(p => p.ID !== productId);
    saveCart(cart);
}

// Renderizar la página del carrito al cargar
document.addEventListener('DOMContentLoaded', renderCartPage);