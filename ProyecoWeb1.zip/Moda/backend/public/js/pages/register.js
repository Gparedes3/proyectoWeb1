import { api } from '../api.js';

const registerForm = document.getElementById('register-form');
const errorDiv = document.getElementById('form-error');

registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorDiv.style.display = 'none';

    // 1. Obtener todos los valores del formulario
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phoneNumber = document.getElementById('phone').value;
    const addressLine1 = document.getElementById('address').value;
    const city = document.getElementById('city').value;
    const postalCode = document.getElementById('postalCode').value;
    const country = document.getElementById('country').value;
    const password = document.getElementById('password').value;
    const passwordConfirm = document.getElementById('password-confirm').value;

    // 2. Validar que las contraseñas coincidan
    if (password !== passwordConfirm) {
        errorDiv.textContent = 'Las contraseñas no coinciden.';
        errorDiv.style.display = 'block';
        return; // Detener el envío del formulario
    }

    // 3. Crear el objeto con todos los datos para enviar al backend
    const userData = {
        name,
        email,
        password, // Enviar la contraseña en texto plano, el backend la encriptará
        phoneNumber,
        addressLine1,
        city,
        postalCode,
        country,
    };

    try {
        const data = await api.register(userData);
        alert(data.message + ". Ahora puedes iniciar sesión.");
        window.location.href = '/public/login.html';
    } catch (error) {
        errorDiv.textContent = error.message;
        errorDiv.style.display = 'block';
    }
});