import { api } from '../api.js';
import { isLoggedIn } from '../auth.js';

document.addEventListener('DOMContentLoaded', async () => {
    if (!isLoggedIn()) {
        window.location.href = '/public/login.html';
        return;
    }

    const ordersList = document.getElementById('orders-list');
    try {
        const orders = await api.getOrders();
        if (orders && orders.length > 0) {
            let html = '';
            orders.forEach(order => {
                const orderDate = new Date(order.CreatedAt).toLocaleDateString('es-ES');
                html += `
                    <div class="order-card">
                        <div class="order-card-header">
                            <div>
                                <strong>Pedido #${order.ID}</strong>
                                <p>Fecha: ${orderDate}</p>
                            </div>
                            <div>
                                <span class="order-status">Entregado</span>
                                <strong>Total: $${order.total_amount.toFixed(2)}</strong>
                            </div>
                        </div>
                        <div class="order-card-body">
                            ${order.items.map(item => `
                                <div class="order-item">
                                    <img src="${item.product.image_url}" class="order-item-img">
                                    <div>
                                        <p><strong>${item.product.name}</strong></p>
                                        <p>Cantidad: ${item.quantity} x $${item.price.toFixed(2)}</p>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>`;
            });
            ordersList.innerHTML = html;
        } else {
            ordersList.innerHTML = `<p>Aún no has realizado ningún pedido.</p>`;
        }
    } catch (error) {
        ordersList.innerHTML = `<p class="error-message">Error al cargar tus pedidos.</p>`;
    }
});