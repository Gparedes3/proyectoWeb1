import { api } from '../api.js';
import { isLoggedIn } from '../auth.js';

document.addEventListener('DOMContentLoaded', () => {
    if (!isLoggedIn()) {
        window.location.href = '/public/login.html';
        return;
    }

    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart.length === 0) {
        window.location.href = '/public/cart.html';
        return;
    }

    const summaryContainer = document.getElementById('summary-items-container');
    const totalAmountEl = document.getElementById('summary-total-amount');
    let total = 0;

    cart.forEach(item => {
        total += item.price * item.quantity;
        const itemEl = document.createElement('div');
        itemEl.className = 'summary-item';
        itemEl.innerHTML = `
            <img src="${item.image_url}" alt="${item.name}">
            <div>${item.name} (x${item.quantity})</div>
            <strong>$${(item.price * item.quantity).toFixed(2)}</strong>
        `;
        summaryContainer.appendChild(itemEl);
    });
    totalAmountEl.textContent = `$${total.toFixed(2)}`;

    // Simulación de pago
    document.getElementById('place-order-btn').addEventListener('click', async () => {
        const errorDiv = document.getElementById('form-error');
        errorDiv.style.display = 'none';

        const itemsToOrder = cart.map(item => ({
            product_id: item.ID,
            quantity: item.quantity,
            price: item.price,
        }));

        try {
            const result = await api.createOrder(itemsToOrder);
            alert('¡Gracias! ' + result.message);
            localStorage.removeItem('cart');
            window.location.href = '/public/orders.html';
        } catch (error) {
            errorDiv.textContent = error.message;
            errorDiv.style.display = 'block';
        }
    });
});