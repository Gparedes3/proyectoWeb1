import { api } from '../api.js';
import { updateCartCount } from '../main.js';

document.addEventListener('DOMContentLoaded', () => {
    // Referencias a los elementos del DOM que vamos a manipular
    const productGrid = document.getElementById('product-grid');
    const categoryFilters = document.getElementById('category-filters');
    const shopTitle = document.getElementById('shop-title');

    /**
     * Carga productos desde la API y los muestra en la parrilla.
     * @param {string} categoryId - El ID de la categoría para filtrar. Si está vacío, carga todos.
     * @param {string} categoryName - El nombre de la categoría para mostrarlo en el título.
     */
    async function loadProducts(categoryId = '', categoryName = 'Todos los Productos') {
        productGrid.innerHTML = '<p>Cargando productos...</p>';
        shopTitle.textContent = categoryName;
        try {
            const products = await api.getProducts(categoryId);
            renderProducts(products);
        } catch (error) {
            productGrid.innerHTML = '<p class="error-message">Error al cargar los productos. Intenta de nuevo más tarde.</p>';
        }
    }

    /**
     * Renderiza la lista de productos en el DOM.
     * @param {Array<object>} products - El array de productos a mostrar.
     */
    function renderProducts(products) {
        productGrid.innerHTML = '';
        if (!products || products.length === 0) {
            productGrid.innerHTML = '<p>No hay productos en esta categoría.</p>';
            return;
        }
        products.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <img src="${product.image_url}" alt="${product.name}" class="product-image">
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <p class="product-price">$${product.price.toFixed(2)}</p>
                    <button class="btn btn-primary add-to-cart-btn" data-product-id="${product.ID}">Añadir al Carrito</button>
                </div>
            `;
            // Guardar los datos completos del producto en el botón para fácil acceso
            card.querySelector('.add-to-cart-btn').dataset.product = JSON.stringify(product);
            productGrid.appendChild(card);
        });

        // Añadir event listeners a los nuevos botones de "Añadir al Carrito"
        document.querySelectorAll('.add-to-cart-btn').forEach(button => {
            button.addEventListener('click', handleAddToCart);
        });
    }

    /**
     * Carga y renderiza los filtros de categorías.
     */
    async function loadCategories() {
        try {
            const categories = await api.getCategories();
            categoryFilters.innerHTML = `
                <a href="#" class="category-link active" data-id="">Todos</a>
            `;
            categories.forEach(parent => {
                let subcategoriesHtml = parent.children.map(child =>
                    `<li><a href="#" class="category-link" data-id="${child.ID}">${child.name}</a></li>`
                ).join('');

                categoryFilters.innerHTML += `
                    <div class="category-group">
                        <h4 class="parent-category">${parent.name}</h4>
                        <ul>${subcategoriesHtml}</ul>
                    </div>
                `;
            });

            // Añadir event listeners a los nuevos enlaces de categoría
            document.querySelectorAll('.category-link').forEach(link => {
                link.addEventListener('click', handleCategoryClick);
            });

        } catch (error) {
            categoryFilters.innerHTML = '<p class="error-message">No se pudieron cargar las categorías.</p>';
        }
    }

    /**
     * Maneja el clic en un enlace de categoría.
     * @param {Event} e - El evento de clic.
     */
    function handleCategoryClick(e) {
        e.preventDefault();
        const categoryId = e.target.dataset.id;
        const categoryName = e.target.textContent;

        // Actualizar la clase 'active' para el filtro seleccionado
        document.querySelectorAll('.category-link').forEach(link => link.classList.remove('active'));
        e.target.classList.add('active');
        
        loadProducts(categoryId, categoryName);
    }
    
    /**
     * Maneja el clic en el botón "Añadir al Carrito".
     * @param {Event} e - El evento de clic.
     */
    function handleAddToCart(e) {
        const productData = JSON.parse(e.target.dataset.product);
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        
        const existingItem = cart.find(item => item.ID === productData.ID);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            productData.quantity = 1;
            cart.push(productData);
        }
        
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount(); // Actualiza el contador del ícono del carrito
        
        // Pequeña animación de confirmación
        e.target.textContent = '¡Añadido!';
        setTimeout(() => {
            e.target.textContent = 'Añadir al Carrito';
        }, 1500);
    }

    // --- INICIALIZACIÓN DE LA PÁGINA ---
    loadCategories(); // Cargar filtros de categoría primero
    loadProducts();   // Cargar todos los productos al inicio
});