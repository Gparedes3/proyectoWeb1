export function saveAuthData(token, username) {
    localStorage.setItem('authToken', token);
    localStorage.setItem('username', username);
}

export function clearAuthData() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('username');
}

export function isLoggedIn() {
    return !!localStorage.getItem('authToken');
}

export function getUsername() {
    return localStorage.getItem('username');
}