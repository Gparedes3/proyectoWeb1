/**
 * URL base para todas las llamadas a la API del backend.
 */
const API_BASE_URL = '/api/v1';

/**
 * Función genérica para realizar peticiones al backend.
 * Se encarga de añadir el token de autenticación a las cabeceras
 * y de gestionar las respuestas y errores.
 * @param {string} endpoint - El endpoint de la API al que se llamará (ej. '/login').
 * @param {object} options - Opciones de configuración para la petición fetch (method, body, etc.).
 * @returns {Promise<any>} - La respuesta JSON del servidor.
 * @throws {Error} - Lanza un error si la petición falla o la respuesta no es OK.
 */
async function request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    // Obtener el token de autenticación del localStorage.
    const token = localStorage.getItem('authToken');

    // Configurar las cabeceras por defecto.
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    // Si existe un token, añadirlo a la cabecera de Autorización.
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const config = {
        ...options,
        headers,
    };

    try {
        const response = await fetch(url, config);
        const data = await response.json();

        // Si la respuesta del servidor no es exitosa (ej. status 400, 401, 500),
        // lanzamos un error con el mensaje que nos proporciona el backend.
        if (!response.ok) {
            throw new Error(data.error || 'Algo salió mal en la petición al servidor.');
        }

        return data;
    } catch (error) {
        console.error(`Error en la llamada API a ${endpoint}:`, error);
        // Re-lanzamos el error para que pueda ser capturado por quien llamó a la función.
        throw error;
    }
}

/**
 * Objeto que exporta todas las funciones para interactuar con la API.
 * Cada función utiliza el helper 'request' para realizar la llamada.
 */
export const api = {
    /**
     * Inicia sesión de un usuario.
     * @param {string} email - El correo del usuario.
     * @param {string} password - La contraseña del usuario.
     * @returns {Promise<{message: string, token: string, username: string}>}
     */
    login: (email, password) => request('/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
    }),

    /**
     * Registra un nuevo usuario.
     * @param {object} userData - Datos del usuario (name, email, password, etc.).
     * @returns {Promise<{message: string}>}
     */
    register: (userData) => request('/register', {
        method: 'POST',
        body: JSON.stringify(userData),
    }),

    /**
     * Obtiene todas las categorías principales con sus subcategorías.
     * @returns {Promise<Array<object>>}
     */
    getCategories: () => request('/categories'),

    /**
     * Obtiene una lista de productos.
     * @param {string} [categoryId] - Opcional. ID de la categoría para filtrar los productos.
     * @returns {Promise<Array<object>>}
     */
    getProducts: (categoryId = '') => {
        const endpoint = categoryId ? `/products?category_id=${categoryId}` : '/products';
        return request(endpoint);
    },

    /**
     * Crea un nuevo pedido. Esta es una ruta protegida.
     * @param {Array<object>} items - Un array de los artículos en el carrito.
     * @returns {Promise<{message: string, orderId: number}>}
     */
    createOrder: (items) => request('/orders', {
        method: 'POST',
        body: JSON.stringify(items),
    }),

    /**
     * Obtiene el historial de pedidos del usuario autenticado. Ruta protegida.
     * @returns {Promise<Array<object>>}
     */
    getOrders: () => request('/orders'),
};