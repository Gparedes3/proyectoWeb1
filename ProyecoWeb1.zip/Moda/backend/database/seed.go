package database

import (
	"log"
	"moda-backend/configs"
	"moda-backend/models"

	"golang.org/x/crypto/bcrypt"
)

func Seed() {
	db := configs.DB

	// Limpiar tablas para un inicio limpio
	log.Println("Limpiando la base de datos...")
	db.Exec("SET FOREIGN_KEY_CHECKS = 0;")
	db.Exec("TRUNCATE TABLE order_items;")
	db.Exec("TRUNCATE TABLE orders;")
	db.Exec("TRUNCATE TABLE products;")
	db.Exec("TRUNCATE TABLE categories;")
	db.Exec("TRUNCATE TABLE users;")
	db.Exec("SET FOREIGN_KEY_CHECKS = 1;")

	// --- CREAR USUARIO DE PRUEBA ---
	log.Println("Creando usuario de prueba...")
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte("password123"), bcrypt.DefaultCost)
	if err != nil {
		log.Fatalf("No se pudo hashear la contraseña: %v", err)
	}
	user := models.User{
		Name:     "Usuario de Prueba",
		Email:    "test@example.com",
		Password: string(hashedPassword),
	}
	db.Create(&user)
	log.Println("Usuario de prueba creado -> Email: test@example.com | Pass: password123")

	// --- CREAR CATEGORÍAS ---
	log.Println("Creando categorías...")
	menCategory := models.Category{Name: "Hombres"}
	womenCategory := models.Category{Name: "Mujeres"}
	db.Create(&menCategory)
	db.Create(&womenCategory)

	subMen := []models.Category{
		{Name: "Camisas", ParentID: &menCategory.ID},
		{Name: "Pantalones", ParentID: &menCategory.ID},
	}
	db.Create(&subMen)

	subWomen := []models.Category{
		{Name: "Vestidos", ParentID: &womenCategory.ID},
		{Name: "Blusas", ParentID: &womenCategory.ID},
	}
	db.Create(&subWomen)
	log.Println("Categorías creadas.")

	// --- CREAR PRODUCTOS CON LA IMAGEN DE PRUEBA ---
	log.Println("Creando productos...")
	testImageUrl := "https://th.bing.com/th/id/OIP.CxiamFmo1_bsDcJuusFopgHaHa?r=0&rs=1&pid=ImgDetMain"
	products := []models.Product{
		{Name: "Camisa de Lino Azul", Description: "Fresca y elegante", Price: 49.99, ImageURL: testImageUrl, CategoryID: subMen[0].ID},
		{Name: "Pantalón Chino Beige", Description: "Versátil y cómodo", Price: 59.99, ImageURL: testImageUrl, CategoryID: subMen[1].ID},
		{Name: "Vestido Floral de Verano", Description: "Ligero y femenino", Price: 79.99, ImageURL: testImageUrl, CategoryID: subWomen[0].ID},
		{Name: "Blusa de Seda Blanca", Description: "Un clásico para cualquier ocasión", Price: 69.99, ImageURL: testImageUrl, CategoryID: subWomen[1].ID},
	}
	db.Create(&products)
	log.Println("Productos creados.")
}
