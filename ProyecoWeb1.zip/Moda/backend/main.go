package main

import (
	"log"
	"moda-backend/configs"
	"moda-backend/database"
	"moda-backend/models"
	"moda-backend/routes"
	"os"

	"github.com/gin-gonic/gin"
)

func main() {
	configs.ConnectToDB()
	configs.DB.AutoMigrate(
		&models.User{},
		&models.Category{},
		&models.Product{},
		&models.Order{},
		&models.OrderItem{},
	)

	// Sembrar la base de datos si se pasa un argumento
	if len(os.Args) > 1 && os.Args[1] == "seed" {
		database.Seed()
		log.Println("Database seeding completed. Exiting.")
		return
	}

	router := gin.Default()
	routes.SetupRouter(router)

	// Servir archivos estáticos del frontend
	router.Static("/public", "./public")
	// Redirigir la raíz a la página de inicio
	router.GET("/", func(c *gin.Context) {
		c.Redirect(301, "/public/index.html")
	})

	if err := router.Run(":8084"); err != nil {
		log.Fatalf("Error iniciando el servidor: %v", err)
	}
}
