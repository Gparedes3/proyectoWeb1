package routes

import (
	"moda-backend/controllers"
	"moda-backend/middleware"

	"github.com/gin-gonic/gin"
)

func SetupRouter(router *gin.Engine) {
	api := router.Group("/api/v1")
	{
		// Rutas públicas
		api.POST("/register", controllers.Register)
		api.POST("/login", controllers.Login)
		api.GET("/products", controllers.GetProducts)
		api.GET("/categories", controllers.GetCategories)

		// Rutas protegidas
		protected := api.Group("/")
		protected.Use(middleware.JwtAuthMiddleware())
		{
			protected.POST("/orders", controllers.CreateOrder)
			protected.GET("/orders", controllers.GetUserOrders)
			// Aquí irían más rutas protegidas, como ver perfil, etc.
		}
	}
}
