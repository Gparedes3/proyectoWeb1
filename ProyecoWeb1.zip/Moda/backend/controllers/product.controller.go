package controllers

import (
	"moda-backend/configs"
	"moda-backend/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

func GetProducts(c *gin.Context) {
	categoryID := c.Query("category_id")
	var products []models.Product

	query := configs.DB
	if categoryID != "" {
		query = query.Where("category_id = ?", categoryID)
	}

	if err := query.Find(&products).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Error al obtener productos"})
		return
	}
	c.JSON(http.StatusOK, products)
}

func GetCategories(c *gin.Context) {
	var categories []models.Category
	if err := configs.DB.Where("parent_id IS NULL").Preload("Children").Find(&categories).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Error al obtener categorías"})
		return
	}
	c.JSON(http.StatusOK, categories)
}
