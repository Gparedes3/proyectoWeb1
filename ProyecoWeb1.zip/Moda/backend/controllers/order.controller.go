package controllers

import (
	"moda-backend/configs"
	"moda-backend/models"
	"moda-backend/utils"
	"net/http"

	"github.com/gin-gonic/gin"
)

type CartItemInput struct {
	ProductID uint    `json:"product_id" binding:"required"`
	Quantity  int     `json:"quantity" binding:"required"`
	Price     float64 `json:"price" binding:"required"`
}

func CreateOrder(c *gin.Context) {
	userID, err := utils.ExtractTokenID(c)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "No autorizado"})
		return
	}

	var input []CartItemInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	tx := configs.DB.Begin()
	var totalAmount float64
	for _, item := range input {
		totalAmount += float64(item.Quantity) * item.Price
	}

	order := models.Order{
		UserID:      userID,
		TotalAmount: totalAmount,
		Status:      "Completed",
	}
	if err := tx.Create(&order).Error; err != nil {
		tx.Rollback()
		c.JSON(http.StatusInternalServerError, gin.H{"error": "No se pudo crear el pedido"})
		return
	}

	for _, item := range input {
		orderItem := models.OrderItem{
			OrderID:   order.ID,
			ProductID: item.ProductID,
			Quantity:  item.Quantity,
			Price:     item.Price,
		}
		if err := tx.Create(&orderItem).Error; err != nil {
			tx.Rollback()
			c.JSON(http.StatusInternalServerError, gin.H{"error": "No se pudieron guardar los artículos del pedido"})
			return
		}
	}

	tx.Commit()
	c.JSON(http.StatusOK, gin.H{"message": "Pedido realizado con éxito", "orderId": order.ID})
}

func GetUserOrders(c *gin.Context) {
	userID, err := utils.ExtractTokenID(c)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "No autorizado"})
		return
	}

	var orders []models.Order
	if err := configs.DB.Where("user_id = ?", userID).Preload("Items.Product").Order("created_at desc").Find(&orders).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Error al obtener los pedidos"})
		return
	}
	c.JSON(http.StatusOK, orders)
}
