package controllers

import (
	"moda-backend/configs"
	"moda-backend/models"
	"moda-backend/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

// --- FUNCIÓN DE REGISTRO (SIN CAMBIOS, YA ESTABA BIEN) ---
func Register(c *gin.Context) {
	var input models.User
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(input.Password), bcrypt.DefaultCost)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "No se pudo encriptar la contraseña"})
		return
	}

	newUser := models.User{
		Name:         input.Name,
		Email:        input.Email,
		Password:     string(hashedPassword),
		PhoneNumber:  input.PhoneNumber,
		AddressLine1: input.AddressLine1,
		City:         input.City,
		PostalCode:   input.PostalCode,
		Country:      input.Country,
	}

	if err := configs.DB.Create(&newUser).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "El correo electrónico ya está en uso"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Registro exitoso"})
}

// --- FUNCIÓN DE LOGIN CORREGIDA ---
func Login(c *gin.Context) {
	var req struct {
		Email    string `json:"email" binding:"required"`
		Password string `json:"password" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Datos inválidos"})
		return
	}

	var user models.User
	if err := configs.DB.Where("email = ?", req.Email).First(&user).Error; err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Credenciales incorrectas"})
		return
	}

	// --- LA LÍNEA CORREGIDA ESTÁ AQUÍ ---
	// Se cambió '=' por ':=' para declarar la variable 'err' correctamente.
	err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password))
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Credenciales incorrectas"})
		return
	}

	token, err := utils.GenerateToken(user.ID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "No se pudo generar el token"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":  "Login exitoso",
		"token":    token,
		"username": user.Name,
	})
}
